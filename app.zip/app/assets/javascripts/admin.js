//= require yarn_components/raven-js/dist/raven
//= require yarn_components/perfect-scrollbar/dist/perfect-scrollbar
//= require ./lib/sentry

//= require jquery3
//= require jquery_ujs
//= require popper
//= require bootstrap
//= require bootstrap-datetimepicker
//= require moment.min
//= require daterangepicker
//= require jsoneditor.min
//= require admin/app
//= require theme/sidebar