# encoding: UTF-8
# frozen_string_literal: true



class Notice < ActiveRecord::Base

end

# == Schema Information
# Schema version: 20190815105500
#
# Table name: notices
#
#  id           :integer          not null, primary key
#  notice_title :string(255)      not null
#  description  :text(65535)
#  enabled      :boolean          default(TRUE), not null
#  from_date    :datetime         not null
#  to_date      :datetime         not null
#  created_at   :datetime         not null
#
